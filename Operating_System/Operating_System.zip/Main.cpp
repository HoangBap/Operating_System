﻿#include"Menu.h"
using namespace std;

//10 điểm hệ điều hành
int main()
{
	/*cout << hexToInt("18");
	system("pause");*/
	printMainMenu();
}
